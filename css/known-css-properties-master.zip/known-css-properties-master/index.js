module.exports.all = require('./data/all.json').properties;
